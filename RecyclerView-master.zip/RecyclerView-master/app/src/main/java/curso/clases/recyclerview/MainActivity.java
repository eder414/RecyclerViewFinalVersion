package curso.clases.recyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import java.util.List;

import curso.clases.recyclerview.Adapters.RecyclerViewAdapter;
import curso.clases.recyclerview.Models.Persona;
import curso.clases.recyclerview.Utilities.Utilities;

public class MainActivity extends AppCompatActivity {
    List<Persona> lPersona;
    private LayoutInflater mInflater;

    RecyclerViewAdapter.ItemClickListener itemClickListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lPersona = Utilities.GetList();
        mInflater = LayoutInflater.from(this);

        /*instancio interface*/
        itemClickListener = new RecyclerViewAdapter.ItemClickListener() {
            @Override
            public void onItemClick(Persona lPersona, int position, View view) {
                GetPersonaData(lPersona,position,view);
            }
        };

        /*constructor del adaptador*/
        RecyclerViewAdapter recyclerViewAdapter = new RecyclerViewAdapter(lPersona,mInflater,this,itemClickListener);

        RecyclerView recyclerView = findViewById(R.id.recyclereView);
        recyclerView.setHasFixedSize(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.HORIZONTAL));

        /*añadimos adaptador a recyclerview*/
        recyclerView.setAdapter(recyclerViewAdapter);
    }

    private void GetPersonaData(Persona lPersona, int position, View view) {
        switch (view.getId()){
            case R.id.imageView:
                Toast.makeText(this,"presionaste la imagen: "+lPersona.getNombre(),Toast.LENGTH_SHORT).show();
                break;
            case R.id.textNombre:
                Toast.makeText(this,"presionaste el nombre: "+lPersona.getNombre(),Toast.LENGTH_SHORT).show();
                break;
            default:
                Toast.makeText(this,"presiona un elemento correcto: "+lPersona.getNombre(),Toast.LENGTH_SHORT).show();
                break;
        }
    }
}