package curso.clases.recyclerview.Utilities;

import java.util.ArrayList;
import java.util.List;

import curso.clases.recyclerview.Models.Persona;

public class Utilities {
    public static List<Persona> GetList(){
        List<Persona> lPersona = new ArrayList<Persona>();
        lPersona.add(new Persona("https://www.pngmart.com/files/10/Dog-Looking-PNG-Photos.png",
                "Eder Alexis",
                "El bordonal",
                "#FF9999"));
        lPersona.add(new Persona("https://img.mipon.org/wp-content/uploads/2019/04/05164321/saitama-one-punch-man-oppai-shirt1-1024x569.jpg",
                "Juan Carlos",
                "lazaro Cardenas",
                "#CCFFFF"));
        lPersona.add(new Persona("https://m.media-amazon.com/images/I/81B-F8ocJXL._AC_SY355_.jpg",
                "Eder Alexis",
                "El bordonal",
                "#FFCCFF"));
        lPersona.add(new Persona("https://images.hola.com/imagenes/decoracion/20211230202142/cultivar-palmeras-exterior-mc/1-36-312/cuidados-palmeras-exterior-2-a.jpg?tx=w_360",
                "Eder Alexis",
                "El bordonal",
                "#990000"));
        lPersona.add(new Persona("https://curiosfera-animales.com/wp-content/uploads/2016/09/que-comen-los-cangrejos.jpg",
                "Eder Alexis",
                "El bordonal",
                "#37B6D5"));
        return lPersona;

    }
}
